# pplaaf.org 
## Plateforme de Protection des Lanceurs d'Alerte en Afrique
## Platform for the Protection of Whistleblowers in Africa

The public website for PPLAAF - Platform for the Protection of Whistleblowers in Africa
Please do send pull requests for any corrections or improvements to the site
